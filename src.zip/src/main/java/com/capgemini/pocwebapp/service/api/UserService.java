package com.capgemini.pocwebapp.service.api;

import java.util.List;

import com.capgemini.pocwebapp.dao.entity.User;


public interface UserService {
	
	User findById(int id);
	
	User findBySSO(String sso);
	
	void saveUser(User user);
	
	void updateUser(User user);
	
	void deleteUserBySSO(String sso);

	List<User> findAllUsers(); 
	
	boolean isUserSSOUnique(Integer id, String sso);
	
	List<User> getallProfile();

}
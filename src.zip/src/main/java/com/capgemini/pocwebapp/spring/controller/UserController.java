package com.capgemini.pocwebapp.spring.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.capgemini.pocwebapp.dao.entity.User;
import com.capgemini.pocwebapp.dao.entity.UserProfile;
import com.capgemini.pocwebapp.service.api.UserProfileService;
import com.capgemini.pocwebapp.service.api.UserService;



@Controller
@RequestMapping("/")
@SessionAttributes("roles")
public class UserController extends BaseController{

	@Autowired
	UserService userService;
	
	@Autowired
	UserProfileService userProfileService;
	
	/**
	 * This method will list all existing users.
	 */
	@RequestMapping(value = {"/list"}, method = RequestMethod.GET)
	public String listUsers(ModelMap model) {

		List<User> users = userService.findAllUsers();
		model.addAttribute("users", users);
		model.addAttribute("loggedinuser", super.getPrincipal());
		return "userslist";
	}
	
	@RequestMapping(value = { "/","/home" }, method = RequestMethod.GET)
    public String home(ModelMap model,Principal principal) {
          String name = principal.getName(); //get logged in username
          model.addAttribute("name", name);
                    
         System.out.println("This is the username"+name);
                    return "home";
    }
	
	/**
	 * This method will list all existing users.
	 */
	@RequestMapping(value = { "/userpermission" }, method = RequestMethod.GET)
	public String listRoles(ModelMap model) {
		
		List<User> usrprofile =userService.getallProfile();
		List<String[]> userP = new ArrayList<String[]>();
		for(User user : usrprofile) {
			String[] permission = new String[2];
			permission[0] = user.getFirstName();
			permission[1] = user.getUserProfiles().toString();
			userP.add(permission);
		}
		System.out.println(usrprofile);
		model.addAttribute("users", userP);
		model.addAttribute("loggedinuser", super.getPrincipal());
		return "userScreenPermission";
	}
	
	/**
	 * This method will return the usermenu right page 
	 */
	@RequestMapping(value = { "/usermenuright" }, method = RequestMethod.GET)
	public String menuRight(ModelMap model) {
		
	return "userMenuRights";
	}

	/**
	 * This method will provide the medium to add a new user.
	 */
	@RequestMapping(value = { "/newuser" }, method = RequestMethod.GET)
	public String newUser(ModelMap model) {
		User user = new User();
		model.addAttribute("user", user);
		model.addAttribute("edit", false);
		model.addAttribute("loggedinuser", super.getPrincipal());
		return "registration";
	}

	/**
	 * This method will be called on form submission, handling POST request for
	 * saving user in database. It also validates the user input
	 */
	@RequestMapping(value = { "/newuser" }, method = RequestMethod.POST)
	public String saveUser(@Valid User user, BindingResult result,
			ModelMap model) {

		if (result.hasErrors()) {
			List<User> users = userService.findAllUsers();
			 model.addAttribute("users",users);
			return "registration";
		}

		/*
		 * Preferred way to achieve uniqueness of field [sso] should be implementing custom @Unique annotation 
		 * and applying it on field [sso] of Model class [User].
		 * 
		 * Below mentioned peace of code [if block] is to demonstrate that you can fill custom errors outside the validation
		 * framework as well while still using internationalized messages.
		 * 
		 */
		if(!userService.isUserSSOUnique(user.getId(), user.getSsoId())){
			FieldError ssoError =new FieldError("user","ssoId",messageSource.getMessage("non.unique.ssoId", new String[]{user.getSsoId()}, Locale.getDefault()));
		    result.addError(ssoError);
			return "registration";
		}
		
		userService.saveUser(user);

		model.addAttribute("success", "User " + user.getFirstName() + " "+ user.getLastName() + " registered successfully");
		model.addAttribute("loggedinuser", super.getPrincipal());
		//return "success";
		return "registrationsuccess";
	}


	/**
	 * This method will provide the medium to update an existing user.
	 */
	@RequestMapping(value = { "/edit-user-{ssoId}" }, method = RequestMethod.GET)
	public String editUser(@PathVariable String ssoId, ModelMap model) {
		User user = userService.findBySSO(ssoId);
		model.addAttribute("user", user);
		model.addAttribute("edit", true);
		model.addAttribute("loggedinuser", super.getPrincipal());
		return "registration";
	}
	
	/**
	 * This method will be called on form submission, handling POST request for
	 * updating user in database. It also validates the user input
	 */
	
	@RequestMapping(value = { "/edit-user-{ssoId}" }, method = RequestMethod.POST)
	public String updateUser(@ModelAttribute("user") User user, BindingResult result,
			ModelMap model, @PathVariable String ssoId) {

		if (result.hasErrors()) {
			return "registration";
		}

		userService.updateUser(user);

		model.addAttribute("success", "User " + user.getFirstName() + " "+ user.getLastName() + " updated successfully");
		model.addAttribute("loggedinuser", super.getPrincipal());
		return "registrationsuccess";
	}

	
	/**
	 * This method will delete an user by it's SSOID value.
	 */
	@RequestMapping(value = { "/delete-user-{ssoId}" }, method = RequestMethod.GET)
	public String deleteUser(@PathVariable String ssoId) {
		userService.deleteUserBySSO(ssoId);
		return "redirect:/list";
	}
	

	/**
	 * This method will provide UserProfile list to views
	 */
	@ModelAttribute("roles")
	public List<UserProfile> initializeProfiles() {
		return userProfileService.findAll();
	}

}